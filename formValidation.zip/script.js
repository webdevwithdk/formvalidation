
let nameError = document.getElementById("nameError");
let phoneError = document.getElementById("phoneError");
let emailError = document.getElementById("emailError");
let passwordError = document.getElementById("passwordError");

function nameErrorCheck() {
    var nameInput = document.getElementById("nameInput").value;
    if (nameInput.length == 0 ) {
        nameError.innerHTML = `Required <i class="fa-solid fa-circle-xmark"></i>`;
        nameError.style.color = "red";
        return false;
    }
    if (!nameInput.match(/^[A-Za-z]*\s{1}[A-Za-z]*$/)) {
        nameError.innerHTML = `full Name Required <i class="fa-solid fa-circle-xmark"></i>`;
        nameError.style.color = "red";
        return false;
    }
        nameError.innerHTML = `correct <i class="fa-solid fa-circle-check"></i>`;
        nameError.style.color = "green";
        return true;
}

function phoneValidate() {
    let numberInput = document.getElementById("numberInput").value;
    if (numberInput.length == 0) {
        numberError.innerHTML = `required <i class="fa-solid fa-circle-xmark"></i>`;
        numberError.style.color = "red";
        return false;
    }
    
     if (numberInput.length !== 10) {
        numberError.innerHTML = `should be 10 digit <i class="fa-solid fa-circle-xmark"></i>`;
        numberError.style.color = "red";
        return false;
    }
    if (!numberInput.match(/^[0-9]{10}$/)) {
        numberError.innerHTML = `character found <i class="fa-solid fa-circle-xmark"></i>`;
        numberError.style.color = "red";
        return false;
    }
    numberError.innerHTML = `correct <i class="fa-solid fa-circle-check"></i>`;
    numberError.style.color = "green";
    return true;
};

function validateEmail() {
    let emailInput = document.getElementById("emailInput").value;
    if (emailInput.length == 0) {
        emailError.innerHTML = `required <i class="fa-solid fa-circle-xmark"></i>`;
        emailError.style.color = "red";
        return false;
    }
    if (!emailInput.match(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)) {
        emailError.innerHTML = `enter valid email<i class="fa-solid fa-circle-xmark"></i>`;
        emailError.style.color = "red";
        return false;
    }
    emailError.innerHTML = `correct <i class="fa-solid fa-circle-check"></i>`;
    emailError.style.color = "green";
    return true;
};
function validatePassword() {

    let passwordInput = document.getElementById("passwordInput").value;
    if (passwordInput.length == 0) {
        passwordError.innerHTML = `required <i class="fa-solid fa-circle-xmark"></i>`;
        passwordError.style.color = "red";
        return false;
    }
    if (passwordInput.length < 8) {
        passwordError.innerHTML = `minimum 8 charcters<i class="fa-solid fa-circle-xmark"></i>`;
        passwordError.style.color = "red";
        return false;
    }
    passwordError.innerHTML = `correct <i class="fa-solid fa-circle-check"></i>`;
    passwordError.style.color = "green";
    return true;
};
function validateSubmit() {
    if (!nameErrorCheck() || !phoneValidate() || !validateEmail() || validatePassword()) {
        document.getElementById("submitError").innerHTML = `clear all errors to submit <i class="fa-solid fa-circle-xmark"></i>`;
        return false;
    }
    else {
        document.getElementById("submitError").innerHTML = `Submitted successfully <i class="fa-solid fa-circle-check"></i>`;
        document.getElementById("submitError").style.color = "green";
        return true;
    }
 }